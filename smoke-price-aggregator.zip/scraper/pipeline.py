import json
import os
import psycopg2
from datetime import datetime
from .normalizer import parse_qty_unit, price_per_std, normalize_brand

def db_conn():
    return psycopg2.connect(
        dbname=os.getenv("POSTGRES_DB","prices"),
        user=os.getenv("POSTGRES_USER","postgres"),
        password=os.getenv("POSTGRES_PASSWORD","postgres"),
        host=os.getenv("POSTGRES_HOST","db"),
        port=int(os.getenv("POSTGRES_PORT","5432"))
    )

def upsert_sources(cur, sources):
    for s in sources:
        cur.execute("""
            INSERT INTO sources(name, type, region_support, base_url, has_api)
            VALUES (%s,%s,%s,%s,%s)
            ON CONFLICT (name) DO NOTHING
        """, (s['name'], s['type'], s['region_support'], s.get('base_url'), s.get('has_api', False)))

def upsert_listing(cur, row):
    # products upsert (naive by (name_norm, brand_norm, qty_std, unit_std))
    cur.execute("""
        INSERT INTO products(category, subcategory, name_norm, brand_norm, unit_raw, unit_std, qty_std)
        VALUES (%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT DO NOTHING
        RETURNING id
    """, (row['category'], row.get('subcategory'), row['name_norm'], row.get('brand_norm'),
            row.get('unit_raw'), row['unit_std'], row['qty_std']))
    pid = cur.fetchone()
    if not pid:
        # select existing
        cur.execute("""
          SELECT id FROM products
          WHERE name_norm=%s AND COALESCE(brand_norm,'')=COALESCE(%s,'')
            AND unit_std=%s AND qty_std=%s
        """, (row['name_norm'], row.get('brand_norm'), row['unit_std'], row['qty_std']))
        pid = cur.fetchone()
    product_id = pid[0]

    # source id
    cur.execute("SELECT id FROM sources WHERE name=%s", (row['source'],))
    sid = cur.fetchone()[0]

    cur.execute("""
      INSERT INTO listings(product_id, source_id, title_raw, url, seller, region, availability,
                           price_raw, currency, price_per_std, last_seen_at)
      VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
      RETURNING id
    """, (product_id, sid, row['title_raw'], row['url'], row.get('seller'),
            row.get('region'), row.get('availability','unknown'),
            row['price_raw'], row['currency'], row['price_per_std'], datetime.utcnow()))
    lid = cur.fetchone()[0]

    cur.execute("""
      INSERT INTO price_history(listing_id, price_per_std, captured_at)
      VALUES (%s,%s,%s)
    """, (lid, row['price_per_std'], datetime.utcnow()))

def run_pipeline():
    base = os.path.dirname(__file__)
    demo_sources = json.load(open(os.path.join(base, "demo_sources.json"), encoding="utf-8"))
    demo_listings = json.load(open(os.path.join(base, "demo_listings.json"), encoding="utf-8"))

    conn = db_conn()
    conn.autocommit = False
    try:
        cur = conn.cursor()
        upsert_sources(cur, demo_sources)
        for it in demo_listings:
            unit_std, qty_std = parse_qty_unit(it.get('unit') or str(it.get('qty','1')))
            pps = price_per_std(it['price'], unit_std, qty_std)
            row = {
                'source': it['source'],
                'category': it['category'],
                'subcategory': it.get('subcategory'),
                'name_norm': it['title'].split('  ')[0].strip(),
                'brand_norm': normalize_brand(it.get('brand')),
                'unit_raw': it.get('unit'),
                'unit_std': unit_std,
                'qty_std': qty_std,
                'title_raw': it['title'],
                'url': it['url'],
                'seller': it.get('seller'),
                'region': it.get('region'),
                'availability': 'in_stock',
                'price_raw': it['price'],
                'currency': it.get('currency','UAH'),
                'price_per_std': pps
            }
            upsert_listing(cur, row)
        conn.commit()
        return {"status":"ok","inserted": len(demo_listings)}
    except Exception as e:
        conn.rollback()
        return {"status":"error","message": str(e)}
    finally:
        conn.close()

if __name__ == "__main__":
    print(run_pipeline())
