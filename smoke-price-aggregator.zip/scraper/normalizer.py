import re
from typing import Tuple

def parse_qty_unit(unit_raw: str) -> Tuple[str, float]:
    t = unit_raw.strip().lower().replace(',', '.')
    # kg/L/pcs/meters simplistic handling
    if 'кг' in t or 'kg' in t:
        num = float(re.findall(r'[\d.]+', t)[0])
        return 'kg', num
    if 'л' in t or 'l' in t:
        num = float(re.findall(r'[\d.]+', t)[0])
        return 'L', num
    if 'м' in t and 'мм' not in t:  # meters, keep as pcs std for MVP
        num = float(re.findall(r'[\d.]+', t)[0])
        return 'pcs', num  # later convert meters→pcs or length-based std
    if 'шт' in t or 'pcs' in t:
        num = float(re.findall(r'[\d.]+', t)[0])
        return 'pcs', num
    # fallback: assume kg=1
    return 'kg', 1.0

def price_per_std(price_raw: float, unit_std: str, qty_std: float) -> float:
    if qty_std == 0:
        return price_raw
    return round(price_raw / qty_std, 4)

def normalize_brand(name: str) -> str:
    return name.strip().title() if name else None
