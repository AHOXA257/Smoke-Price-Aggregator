Place real source-specific scrapers here (API/Playwright/Scrapy). Register them in pipeline.py
