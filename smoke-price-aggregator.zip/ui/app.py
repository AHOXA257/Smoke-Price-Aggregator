import os, requests, pandas as pd, streamlit as st

API = f"http://backend:8000"
st.set_page_config(page_title="Агрегатор цін сировини", layout="wide")
st.title("Сировина для копчення — агрегатор цін (MVP)")

if st.button("Оновити дані"):
    try:
        r = requests.post(f"{API}/api/refresh", timeout=60)
        st.success(f"Пайплайн: {r.json()}")
    except Exception as e:
        st.error(f"Помилка: {e}")

cols = st.columns(4)
with cols[0]:
    region = st.selectbox("Регіон", ["","Kyiv","Lviv","Odesa"])
with cols[1]:
    category = st.selectbox("Категорія", ["","wood.chips","wood.bricks","salt.nitrite","spice","casing","raw.meat","raw.fish","raw.cheese"])
with cols[2]:
    try:
        s = requests.get(f"{API}/api/sources", timeout=10).json().get("sources",[])
    except Exception:
        s = []
    source = st.selectbox("Джерело", [""]+s)
with cols[3]:
    st.write("")

params = {}
if region: params["region"]=region
if category: params["category"]=category
if source: params["source"]=source

try:
    data = requests.get(f"{API}/api/listings", params=params, timeout=30).json()
    df = pd.DataFrame(data)
    if not df.empty:
        st.dataframe(df, use_container_width=True)
        st.download_button("Експорт CSV", df.to_csv(index=False).encode('utf-8'), file_name="prices.csv")
    else:
        st.info("Нічого не знайдено (спробуйте натиснути 'Оновити дані').")
except Exception as e:
    st.error(f"Помилка запиту: {e}")

st.subheader("Зведення")
try:
    stats = requests.get(f"{API}/api/stats", timeout=30).json()
    st.dataframe(pd.DataFrame(stats))
except Exception as e:
    st.warning(f"Статистика недоступна: {e}")
