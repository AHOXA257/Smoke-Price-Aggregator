from pydantic import BaseModel
from typing import Optional

class Listing(BaseModel):
    id: int
    category: str
    subcategory: Optional[str]
    name_norm: str
    brand_norm: Optional[str]
    unit_std: str
    qty_std: float
    price_raw: float
    currency: str
    price_per_std: float
    source: str
    seller: Optional[str]
    region: Optional[str]
    url: str
    last_seen_at: str
