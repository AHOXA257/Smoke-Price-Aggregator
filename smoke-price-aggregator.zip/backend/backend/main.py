from fastapi import FastAPI
from typing import Optional
from .crud import list_listings, source_stats
import scraper.pipeline as pipeline

app = FastAPI(title="Smoke Price Aggregator API")

@app.get("/api/listings")
def get_listings(region: Optional[str]=None, category: Optional[str]=None, source: Optional[str]=None,
                 limit: int=200, offset: int=0):
    data = list_listings({"region":region, "category":category, "source":source}, limit, offset)
    return data

@app.get("/api/stats")
def get_stats():
    return source_stats()

@app.post("/api/refresh")
def refresh():
    return pipeline.run_pipeline()

@app.get("/api/sources")
def sources():
    # simple reflection from listings
    return {"sources": ["Demo Marketplace","Demo Wholesale"]}
