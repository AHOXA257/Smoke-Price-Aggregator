from .db import get_conn

def list_listings(filters: dict, limit=200, offset=0):
    conn = get_conn()
    cur = conn.cursor()
    where = []
    params = []
    if filters.get('region'):
        where.append("l.region = %s")
        params.append(filters['region'])
    if filters.get('category'):
        where.append("p.category = %s")
        params.append(filters['category'])
    if filters.get('source'):
        where.append("s.name = %s")
        params.append(filters['source'])
    cond = (" WHERE " + " AND ".join(where)) if where else ""
    sql = f"""
      SELECT l.id, p.category, p.subcategory, p.name_norm, p.brand_norm,
             p.unit_std, p.qty_std, l.price_raw, l.currency, l.price_per_std,
             s.name as source, l.seller, l.region, l.url, l.last_seen_at
      FROM listings l
      JOIN products p ON p.id = l.product_id
      JOIN sources s  ON s.id = l.source_id
      {cond}
      ORDER BY l.last_seen_at DESC
      LIMIT %s OFFSET %s
    """
    params += [limit, offset]
    cur.execute(sql, params)
    rows = cur.fetchall()
    conn.close()
    cols = ["id","category","subcategory","name_norm","brand_norm","unit_std","qty_std",
            "price_raw","currency","price_per_std","source","seller","region","url","last_seen_at"]
    return [dict(zip(cols, r)) for r in rows]

def source_stats():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
      SELECT p.category, COALESCE(l.region,'N/A') as region,
             AVG(l.price_per_std)::numeric(12,2) as avg_price, COUNT(1) as n
      FROM listings l JOIN products p ON p.id=l.product_id
      GROUP BY 1,2 ORDER BY 1,2
    """)
    rows = cur.fetchall()
    conn.close()
    return [{"category":r[0], "region":r[1], "avg_price":float(r[2]), "n":r[3]} for r in rows]
