INSERT INTO sources (name, type, region_support, base_url, has_api)
VALUES 
  ('Demo Marketplace', 'marketplace', TRUE, 'https://demo.market', FALSE),
  ('Demo Wholesale', 'wholesale', TRUE, 'https://demo.wholesale', FALSE)
ON CONFLICT DO NOTHING;
