CREATE TABLE IF NOT EXISTS sources (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,         -- marketplace|retail|wholesale
  region_support BOOLEAN DEFAULT TRUE,
  base_url TEXT,
  has_api BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS products (
  id SERIAL PRIMARY KEY,
  category TEXT NOT NULL,
  subcategory TEXT,
  name_norm TEXT NOT NULL,
  brand_norm TEXT,
  unit_raw TEXT,
  unit_std TEXT,              -- kg|L|pcs
  qty_std NUMERIC,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS listings (
  id SERIAL PRIMARY KEY,
  product_id INT REFERENCES products(id) ON DELETE CASCADE,
  source_id INT REFERENCES sources(id) ON DELETE CASCADE,
  title_raw TEXT,
  url TEXT,
  seller TEXT,
  region TEXT,
  availability TEXT,
  price_raw NUMERIC,
  currency TEXT,
  price_per_std NUMERIC,
  last_seen_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS price_history (
  id SERIAL PRIMARY KEY,
  listing_id INT REFERENCES listings(id) ON DELETE CASCADE,
  price_per_std NUMERIC,
  captured_at TIMESTAMP DEFAULT NOW()
);
